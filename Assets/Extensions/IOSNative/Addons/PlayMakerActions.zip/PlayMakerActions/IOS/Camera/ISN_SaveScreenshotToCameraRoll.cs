using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Camera")]
	public class ISN_SaveScreenshotToCameraRoll : FsmStateAction {

		
		public override void OnEnter() {
			IOSCamera.instance.SaveScreenshotToCameraRoll();
			Finish();
		}



	}
}



